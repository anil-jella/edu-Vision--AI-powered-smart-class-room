import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json());

// Lazy-initialize Gemini client
let aiClient: GoogleGenAI | null = null;
function getGeminiClient(): GoogleGenAI | null {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey || apiKey === "MY_GEMINI_API_KEY") {
    return null;
  }
  if (!aiClient) {
    aiClient = new GoogleGenAI({
      apiKey: apiKey,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build",
        },
      },
    });
  }
  return aiClient;
}

// Endpoint for AI Teacher Coach Chat
app.post("/api/chat", async (req, res) => {
  try {
    const { message, history, subject } = req.body;
    if (!message) {
      res.status(400).json({ error: "Message is required." });
      return;
    }

    const currentSubject = subject || "Computer Science";
    const systemPrompt = `You are EduVision AI Teacher, a friendly, expert tutor for school and college students. You teach all subjects clearly with examples, analogies, and step-by-step explanations. Current subject: ${currentSubject}. Always:
- Start with a simple one-line summary
- Use numbered steps for processes
- Give real-world examples
- End with a quick tip or memory trick
- Keep responses concise but complete
- Use encouraging language`;

    const client = getGeminiClient();

    if (!client) {
      // Return beautiful fallback tutoring content when API key is unconfigured
      console.warn("Working in demo mode - GEMINI_API_KEY not configured.");
      
      let fallbackText = "";
      const lowerMsg = message.toLowerCase();
      
      if (lowerMsg.includes("photosynthesis")) {
        fallbackText = `**Photosynthesis is how plants use sunlight, water, and carbon dioxide to create oxygen and energy in the form of sugar.**

1. **Light Absorption**: Chlorophyll in plant leaves captures sunlight.
2. **Water Intake**: Roots absorb water from the soil, which travels up the stem.
3. **Carbon Dioxide Capture**: Leaves take in carbon dioxide ($CO_2$) from the air through tiny pores called stomata.
4. **Chemical Reaction**: Solar energy converts water and $CO_2$ into glucose (food) and oxygen ($O_2$).

**Real-World Example**: Think of a leaf as a tiny solar-powered kitchen. The sun is the oven, chlorophyll is the chef, and water/carbon dioxide are the raw ingredients being baked into sweet glucose bread!

**Quick Tip**: Remember **WOW** — **W**ater, **O**xygen, **W**onderful Sunlight. Plants take in Water & Sunlight to release Oxygen!`;
      } else if (lowerMsg.includes("quiz")) {
        fallbackText = `**Here is a quick interactive quiz for you under the subject of ${currentSubject}!**

1. **Question**: Which organelle is known as the powerhouse of the cell, generating chemical energy (ATP)?
   - A) Nucleus
   - B) Mitochondria
   - C) Ribosome
   - D) Golgi Apparatus

**Real-World Example**: This organelle functions like an electricity power plant supplying clean voltage to a bustling city!

**Quick Tip**: "Mit-o-chondria" sounds like "Might-o-chondria" because it gives the cell its "might" (power)! Reply with your answer to get instant feedback!`;
      } else {
        fallbackText = `**I can explain any concept in ${currentSubject} utilizing real-world analogies and simple numbered steps!**
 
1. **Define Your Goal**: Ask me a specific question or ask for a quiz.
2. **Analyze**: I will break down complex mechanisms into friendly explanations.
3. **Practice**: We can run simulated flashcards or diagnostic questions together.
 
**Real-World Example**: Approaching learning step-by-step is like climbing a staircase; instead of leaping to the top, we confidently step on one step at a time!
 
**Quick Tip**: Try asking "Explain photosynthesis" or "Give me a quiz" to see the active AI Teacher schema in action! (Note: Connect your AI API Key in Settings to unlock real-time live model responses).`;
      }
 
      res.json({ text: fallbackText });
      return;
    }
 
    // Convert history format to Gemini format
    const contents: any[] = [];
    if (Array.isArray(history)) {
      history.forEach((msg: any) => {
        contents.push({
          role: msg.role === "assistant" || msg.role === "model" ? "model" : "user",
          parts: [{ text: msg.text || msg.content || "" }]
        });
      });
    }
 
    // Push current user query
    contents.push({
      role: "user",
      parts: [{ text: message }]
    });
 
    const response = await client.models.generateContent({
      model: "gemini-3.5-flash",
      contents: contents,
      config: {
        systemInstruction: systemPrompt,
        temperature: 0.7,
      },
    });
 
    res.json({ text: response.text });
  } catch (error: any) {
    console.error("AI API Error in backend:", error);
    res.status(500).json({ error: error.message || "Failed to fetch response from AI Engine." });
  }
});

// Configure Vite integration or Static File Serving
async function start() {
  if (process.env.NODE_ENV !== "production") {
    // Development Mode
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    // Production Mode
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`EduVision AI Live on http://localhost:${PORT}`);
  });
}

start();
