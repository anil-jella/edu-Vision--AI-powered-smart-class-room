export interface UserProfile {
  name: string;
  rollNo: string;
  email: string;
  password?: string; // plain text for demo configuration
  subject: string;
  faceDescriptor: number[]; // serialized descriptor from face-api.js
  photoBase64: string;
  registeredAt: string;
}

export interface AttendanceRecord {
  id: string;
  studentName: string;
  rollNo: string;
  email: string;
  meetingId: string;
  date: string;
  time: string;
  status: "present" | "absent" | "unauthorized";
  photoBase64: string;
  faceMatchDistance: number;
}

export interface MeetingRecord {
  meetingId: string;
  createdBy: string;
  createdAt: string;
  subject: string;
  participants: string[];
  status: "active" | "ended";
}

export interface ChatMessage {
  role: "user" | "assistant" | "model";
  text: string;
  timestamp: string;
}
