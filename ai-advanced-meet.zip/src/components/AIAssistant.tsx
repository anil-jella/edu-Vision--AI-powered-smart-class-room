import React, { useState, useEffect, useRef } from "react";
import { ChatMessage } from "../types";

interface AIAssistantProps {
  isSidebar?: boolean;
  defaultSubject?: string;
  addToast: (message: string, type: "success" | "error" | "warning" | "info") => void;
  meetingVerifyStatus?: "verified" | "unauthorized" | "searching";
  studentName?: string;
}

const SUBJECTS = [
  "Computer Science",
  "Mathematics",
  "Physics",
  "Chemistry",
  "Biology",
  "History",
  "Geography",
  "English",
  "Economics",
];

const QUICK_CHIPS = [
  "Explain this concept simply",
  "Give me a quiz",
  "Summarize the topic",
  "Show me an example",
  "What are the key points?",
];

export default function AIAssistant({ 
  isSidebar = false, 
  defaultSubject = "Computer Science", 
  addToast,
  meetingVerifyStatus,
  studentName: propStudentName
}: AIAssistantProps) {
  const [selectedSubject, setSelectedSubject] = useState(defaultSubject);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [inputValue, setInputValue] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [activeTypingText, setActiveTypingText] = useState("");
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Typewriter effect state
  const [typewriterQueue, setTypewriterQueue] = useState<string[]>([]);

  // Resolve active student name
  const [resolvedStudentName, setResolvedStudentName] = useState("Student");

  // Scroll to bottom when messages update or typing starts
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, isTyping, activeTypingText]);

  // Adjust greeting when subject changes
  useEffect(() => {
    const storedSession = localStorage.getItem("eduvision_current_user");
    const storedUsers = localStorage.getItem("eduvision_users");
    let nameToUse = propStudentName || "Student";
    if (!propStudentName && storedSession && storedUsers) {
      try {
        const sessionObj = JSON.parse(storedSession);
        const usersObj = JSON.parse(storedUsers);
        const user = usersObj[sessionObj.email];
        if (user) {
          nameToUse = user.name;
        }
      } catch (e) {}
    }
    setResolvedStudentName(nameToUse);

    setMessages([
      {
        role: "assistant",
        text: `Hello, **${nameToUse}**! I am your AI Advanced Teacher. I'm here to help you master **${selectedSubject}** today!

⚠️ **SYSTEM NOTICE**: System check indicates you are currently marked as **ABSENT** for this session. Please connect your live video feed in the lecture room or complete a biometric scan to confirm your active participation.`,
        timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
      },
    ]);
  }, [selectedSubject, propStudentName]);

  // Handle continuous biometric status changes for absent warnings
  useEffect(() => {
    if (meetingVerifyStatus === "searching") {
      // Avoid spamming if the last message is already about student absence
      const lastMsg = messages[messages.length - 1];
      const isAlreadyAbsentNotice = lastMsg?.text.includes("**ABSENT**") && lastMsg?.role === "assistant";
      if (!isAlreadyAbsentNotice) {
        setMessages((prev) => [
          ...prev,
          {
            role: "assistant",
            text: `⚠️ **ATTENTION REQUIRED**: System check indicates that **${resolvedStudentName}** is currently **ABSENT** (out of the camera frame or feed is disabled). Live attendance registry has been adjusted to ABSENT. Please rejoin the camera frame to resolve this.`,
            timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
          },
        ]);
        addToast(`Biometric notification: Student marked as absent.`, "warning");
      }
    }
  }, [meetingVerifyStatus, resolvedStudentName, messages]);

  // Read message off the queue character by character
  useEffect(() => {
    if (typewriterQueue.length > 0) {
      const textToAnimate = typewriterQueue[0];
      let currentIdx = 0;
      setActiveTypingText("");

      const interval = setInterval(() => {
        if (currentIdx < textToAnimate.length) {
          setActiveTypingText((prev) => prev + textToAnimate.charAt(currentIdx));
          currentIdx++;
        } else {
          clearInterval(interval);
          setMessages((prev) => [
            ...prev,
            {
              role: "assistant",
              text: textToAnimate,
              timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
            },
          ]);
          setActiveTypingText("");
          setTypewriterQueue((prev) => prev.slice(1));
        }
      }, 15);

      return () => clearInterval(interval);
    }
  }, [typewriterQueue]);

  const handleSend = async (textToSend: string) => {
    if (!textToSend.trim() || isTyping || typewriterQueue.length > 0) return;

    // Add user message
    const userMsg: ChatMessage = {
      role: "user",
      text: textToSend,
      timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
    };

    setMessages((prev) => [...prev, userMsg]);
    setInputValue("");
    setIsTyping(true);

    try {
      const response = await fetch("/api/chat", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          message: textToSend,
          subject: selectedSubject,
          history: messages,
        }),
      });

      const data = await response.json();
      if (response.ok && data.text) {
        setIsTyping(false);
        // Queue text for typewriter reveal
        setTypewriterQueue((prev) => [...prev, data.text]);
      } else {
        throw new Error(data.error || "Failed to reach AI Teacher.");
      }
    } catch (err: any) {
      console.error(err);
      setIsTyping(false);
      addToast(err.message || "Teacher is busy. Please try writing again.", "error");
      setMessages((prev) => [
        ...prev,
        {
          role: "assistant",
          text: "I apologize, classmate. I hit a small error while processing that topic. Could you restate or check your connection?",
          timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
        },
      ]);
    }
  };

  // Web Speech API STT Integration
  const startSTT = () => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) {
      addToast("Speech recognition is not supported in this browser.", "warning");
      return;
    }

    const recognition = new SpeechRecognition();
    recognition.continuous = false;
    recognition.lang = "en-US";
    recognition.interimResults = false;

    recognition.onstart = () => {
      setIsListening(true);
      addToast("Microphone listening... Speak clearly.", "info");
    };

    recognition.onresult = (event: any) => {
      const text = event.results[0][0].transcript;
      if (text) {
        setInputValue(text);
        addToast("Voice transcribed successfully!", "success");
      }
    };

    recognition.onerror = (e: any) => {
      console.error(e);
      setIsListening(false);
      addToast("Could not recognize speech. Please speak clearly.", "warning");
    };

    recognition.onend = () => {
      setIsListening(false);
    };

    try {
      recognition.start();
    } catch (e) {
      setIsListening(false);
    }
  };

  // Convert markdown-like syntax to bold/italic tags safely for UI presentation
  const renderMessageText = (text: string) => {
    // Escape standard tags first to avoid injection
    let safeText = text
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;");

    // Replace bold (**text**) with standard markup
    safeText = safeText.replace(/\*\*(.*?)\*\*/g, '<strong class="font-bold text-cyan-300">$1</strong>');
    
    // Replace list numbers
    safeText = safeText.replace(/^([0-9]+\.\s.*)/gm, '<span class="block ml-2 text-slate-100">$1</span>');

    return (
      <div 
        className="space-y-1 text-sm tracking-wide text-slate-100" 
        dangerouslySetInnerHTML={{ __html: safeText }} 
      />
    );
  };

  return (
    <div className={`flex flex-col h-full bg-white/5 border border-white/10 ${isSidebar ? "rounded-l-2xl" : "rounded-2xl"} overflow-hidden shadow-2xl backdrop-blur-xl`}>
      {/* Teacher Top Panel */}
      <div className="p-4 border-b border-white/10 bg-white/5 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="relative">
            <div className="w-10 h-10 rounded-full bg-violet-600/30 flex items-center justify-center border border-violet-500/30 text-violet-400">
              <i className="fa-solid fa-robot text-lg animate-pulse" />
            </div>
            <div className="absolute bottom-0 right-0 w-3 h-3 bg-emerald-500 border-2 border-[#1c183a] rounded-full animate-ping" />
            <div className="absolute bottom-0 right-0 w-3 h-3 bg-emerald-500 border-2 border-[#1c183a] rounded-full" />
          </div>
          <div>
            <h3 className="font-bold text-base text-slate-100 tracking-wide flex items-center gap-2">
              AI Advanced Tutor
            </h3>
            <p className="text-xs text-emerald-400 font-medium">● Online Assistant</p>
          </div>
        </div>

        {/* Traditional subject selection dropdown if in sidebar, or simple tag selection */}
        {isSidebar && (
          <select
            value={selectedSubject}
            onChange={(e) => setSelectedSubject(e.target.value)}
            className="bg-white/5 text-slate-200 text-xs rounded-xl border border-white/10 px-2 py-1 outline-none focus:ring-1 focus:ring-cyan-500/50"
          >
            {SUBJECTS.map((sub) => (
              <option key={sub} value={sub} className="bg-slate-900 text-slate-200">
                {sub}
              </option>
            ))}
          </select>
        )}
      </div>

      {/* Horizontal subject selection list for full screen tutor views */}
      {!isSidebar && (
        <div className="px-4 py-3 bg-white/5 border-b border-white/5 flex items-center gap-2 overflow-x-auto no-scrollbar">
          <div className="text-xs font-semibold text-slate-400 shrink-0">Subject:</div>
          {SUBJECTS.map((sub) => (
            <button
              key={sub}
              onClick={() => setSelectedSubject(sub)}
              className={`px-3 py-1 text-xs font-semibold rounded-full border transition-all shrink-0 ${
                selectedSubject === sub
                  ? "bg-violet-600/60 text-slate-100 border-violet-500 shadow-md shadow-violet-500/20"
                  : "bg-white/5 text-slate-400 hover:text-slate-200 border-white/5"
              }`}
            >
              {sub}
            </button>
          ))}
        </div>
      )}

      {/* Messages area */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4 max-h-[500px]">
        {messages.map((msg, i) => (
          <div key={i} className={`flex items-start gap-2.5 ${msg.role === "user" ? "justify-end" : "justify-start"}`}>
            {msg.role !== "user" && (
              <div className="w-8 h-8 rounded-full bg-violet-600/20 text-violet-400 border border-violet-500/20 flex items-center justify-center shrink-0 text-sm">
                <i className="fa-solid fa-robot" />
              </div>
            )}
            <div className="flex flex-col max-w-[85%]">
              <div
                className={`p-3.5 rounded-2xl shadow-lg border ${
                  msg.role === "user"
                    ? "bg-gradient-to-r from-violet-600/80 to-cyan-600/80 border-cyan-500/20 rounded-tr-none text-slate-100"
                    : "bg-white/5 border-white/10 rounded-tl-none text-slate-100"
                }`}
              >
                {renderMessageText(msg.text)}
              </div>
              <span className={`text-[10px] text-slate-400 mt-1 px-1.5 ${msg.role === "user" ? "text-right" : "text-left"}`}>
                {msg.timestamp}
              </span>
            </div>
          </div>
        ))}

        {/* Typewriter active text display */}
        {activeTypingText && (
          <div className="flex items-start gap-2.5 justify-start">
            <div className="w-8 h-8 rounded-full bg-violet-600/20 text-violet-400 border border-violet-500/20 flex items-center justify-center shrink-0 text-sm">
              <i className="fa-solid fa-robot" />
            </div>
            <div className="flex flex-col max-w-[85%]">
              <div className="p-3.5 rounded-2xl rounded-tl-none shadow-lg border bg-white/5 border-white/10 text-slate-100">
                {renderMessageText(activeTypingText)}
                <span className="inline-block w-1.5 h-4 ml-1 bg-violet-400 animate-[blink_0.8s_infinite]" />
              </div>
            </div>
          </div>
        )}

        {/* Bouncing three dot AI typing animation */}
        {isTyping && (
          <div className="flex items-start gap-2.5 justify-start">
            <div className="w-8 h-8 rounded-full bg-violet-600/20 text-violet-400 border border-violet-500/20 flex items-center justify-center shrink-0 text-sm">
              <i className="fa-solid fa-robot animate-spin" />
            </div>
            <div className="bg-white/5 border border-white/10 p-3.5 rounded-2xl rounded-tl-none shadow-lg">
              <div className="flex gap-1.5">
                <div className="w-2.5 h-2.5 bg-violet-400 rounded-full animate-bounce [animation-delay:-0.3s]"></div>
                <div className="w-2.5 h-2.5 bg-violet-400 rounded-full animate-bounce [animation-delay:-0.15s]"></div>
                <div className="w-2.5 h-2.5 bg-cyan-400 rounded-full animate-bounce"></div>
              </div>
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Quick suggest recommendation chips */}
      <div className="px-4 py-2 bg-black/10 border-t border-white/5">
        <div className="flex items-center gap-2 overflow-x-auto no-scrollbar scroll-smooth">
          {QUICK_CHIPS.map((chip) => (
            <button
              key={chip}
              disabled={isTyping || typewriterQueue.length > 0}
              onClick={() => handleSend(chip)}
              className="px-3 py-1 text-[11px] font-semibold text-slate-300 bg-white/5 border border-white/5 rounded-full hover:border-cyan-500/30 hover:bg-white/10 transition-all shrink-0 cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {chip}
            </button>
          ))}
        </div>
      </div>

      {/* Fixed bottom typing console */}
      <form
        onSubmit={(e) => {
          e.preventDefault();
          handleSend(inputValue);
        }}
        className="p-3 bg-white/5 border-t border-white/10 flex items-center gap-2"
      >
        <button
          type="button"
          onClick={startSTT}
          className={`w-10 h-10 rounded-full flex items-center justify-center transition-all shrink-0 ${
            isListening ? "bg-red-500 text-slate-100 animate-pulse border border-red-400" : "bg-white/5 text-slate-300 hover:text-slate-100 hover:bg-white/10 border border-white/5"
          }`}
        >
          <i className="fa-solid fa-microphone text-sm" />
        </button>

        <input
          type="text"
          value={inputValue}
          onChange={(e) => setInputValue(e.target.value)}
          placeholder={`Ask about ${selectedSubject}... e.g. quiz me`}
          className="flex-1 h-10 px-4 bg-white/5 border border-white/10 rounded-full text-sm text-slate-100 placeholder-slate-400 outline-none focus:border-cyan-500/50 focus:ring-1 focus:ring-cyan-500/50 transition-all"
        />

        <button
          type="submit"
          disabled={!inputValue.trim() || isTyping || typewriterQueue.length > 0}
          className="w-10 h-10 rounded-full bg-gradient-to-r from-violet-600 to-cyan-500 flex items-center justify-center text-slate-100 hover:opacity-90 active:scale-95 transition-all shadow-md shadow-violet-500/20 disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer"
        >
          <i className="fa-solid fa-paper-plane text-sm" />
        </button>
      </form>
    </div>
  );
}
