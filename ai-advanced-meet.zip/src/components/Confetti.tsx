import React, { useEffect, useState } from "react";

export default function Confetti({ active }: { active: boolean }) {
  const [particles, setParticles] = useState<any[]>([]);

  useEffect(() => {
    if (active) {
      const list = Array.from({ length: 35 }).map((_, i) => {
        const angle = Math.random() * 360;
        const speed = 50 + Math.random() * 80;
        const color = ["#7c3aed", "#06b6d4", "#10b981", "#f59e0b", "#ef4444", "#3b82f6"][
          Math.floor(Math.random() * 6)
        ];
        const size = 6 + Math.random() * 8;
        return {
          id: i,
          color,
          size,
          angle,
          speed,
          delay: Math.random() * 0.2,
        };
      });
      setParticles(list);
    } else {
      setParticles([]);
    }
  }, [active]);

  if (!active) return null;

  return (
    <div className="absolute inset-0 pointer-events-none overflow-hidden z-40">
      {particles.map((p) => {
        const rad = (p.angle * Math.PI) / 180;
        const tx = Math.cos(rad) * p.speed;
        const ty = Math.sin(rad) * p.speed - 150; // shoot upward then drop

        return (
          <div
            key={p.id}
            className="absolute left-1/2 top-1/2 rounded-sm"
            style={{
              backgroundColor: p.color,
              width: `${p.size}px`,
              height: `${p.size}px`,
              animation: `confettiShoot 1.5s cubic-bezier(0.25, 1, 0.5, 1) ${p.delay}s forwards`,
              transform: "translate(-50%, -50%)",
              "--tx": `${tx}px`,
              "--ty": `${ty}px`,
            } as React.CSSProperties}
          />
        );
      })}
    </div>
  );
}
