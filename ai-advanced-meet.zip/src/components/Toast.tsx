import React, { useEffect } from "react";

export type ToastType = "success" | "error" | "warning" | "info";

export interface ToastMessage {
  id: string;
  message: string;
  type: ToastType;
}

interface ToastProps {
  toasts: ToastMessage[];
  onDismiss: (id: string) => void;
}

export default function Toast({ toasts, onDismiss }: ToastProps) {
  return (
    <div className="fixed bottom-6 right-6 z-50 flex flex-col gap-3 pointer-events-none max-w-sm w-full">
      {toasts.map((toast) => (
        <ToastItem key={toast.id} toast={toast} onDismiss={onDismiss} />
      ))}
    </div>
  );
}

function ToastItem({ toast, onDismiss }: { toast: ToastMessage; onDismiss: (id: string) => void; key?: string }) {
  useEffect(() => {
    const timer = setTimeout(() => {
      onDismiss(toast.id);
    }, 4000);
    return () => clearTimeout(timer);
  }, [toast.id, onDismiss]);

  const borderColors = {
    success: "border-l-emerald-500",
    error: "border-l-rose-500",
    warning: "border-l-amber-500",
    info: "border-l-violet-500",
  };

  const icons = {
    success: "fa-circle-check text-emerald-500",
    error: "fa-triangle-exclamation text-rose-500",
    warning: "fa-circle-exclamation text-amber-500",
    info: "fa-circle-info text-violet-500",
  };

  return (
    <div
      id={`toast-${toast.id}`}
      className={`pointer-events-auto flex items-center justify-between p-4 bg-white/10 backdrop-blur-xl border-l-4 ${borderColors[toast.type]} border-y border-r border-[#ffffff20] rounded-r-xl shadow-2xl transition-all duration-300 animate-slide-in`}
      style={{
        animation: "slideIn 0.3s cubic-bezier(0.16, 1, 0.3, 1) forwards",
      }}
    >
      <div className="flex items-center gap-3">
        <i className={`fa-solid ${icons[toast.type]} text-lg`} />
        <span className="text-sm font-semibold tracking-wide text-slate-100">{toast.message}</span>
      </div>
      <button
        onClick={() => onDismiss(toast.id)}
        className="ml-4 p-1 hover:bg-white/10 rounded-full transition-colors text-slate-400 hover:text-slate-100"
      >
        <i className="fa-solid fa-xmark text-xs" />
      </button>
    </div>
  );
}
